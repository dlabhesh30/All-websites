<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
  extract($_POST);
  echo "$Name";
?>
</body>
</html>